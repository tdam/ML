#!/usr/bin/python

import pandas as pd
import math


def entropy(dataFrame, pos_val, neg_val,tLabel):
    npos = (dataFrame[tLabel] == pos_val).sum()
    nneg = (dataFrame[tLabel] == neg_val).sum()
    n = npos + nneg

    entropy = -((npos/n)*log((npos/n),2) + (nneg/n)*log((nneg/n),2))

    return entropy

def infoGain(dataFrame, attr, pos_val, neg_val, tLabel):
    sEntropy = entropy(dataFrame,pos_val, neg_val, tLabel)
    sSize = len(dataFrame)
    sumEnt = 0

    for i in dataFrame[attr].unique():
        siSize = (dataFrame[attr] == i).sum()
        sumEnt += (siSize/sSize)*entropy(dataFrame.loc[dataFrame[attr]==i])
    
    infogain = sEntropy - sumEnt
    return infogain


